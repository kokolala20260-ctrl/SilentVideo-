# Silent Video

An Android app that removes the sound from a video, saves the silent MP4 to your gallery and lets you share it.

- Black and gold dark UI, original name, logo and icon
- English + **Pashto (پښتو)** with an in-app language switch (right-to-left layout is handled)
- Works fully offline. **No ads, analytics, tracking, login or paid features.** The `INTERNET` permission is explicitly removed from the manifest.
- Kotlin, plain Android views, [Media3 Transformer](https://developer.android.com/media/media3/transformer) (open source, Apache 2.0)

> **Honest status.** This project was written and checked without an Android SDK, so the APK has **not** been built and the app has **not** been run on a device or emulator. See [What has and has not been verified](#what-has-and-has-not-been-verified). Please do the first build yourself using the steps below.

---

## Architecture

```
app/src/main/java/app/silentvideo/
├── core/    Pure Kotlin logic (no Android classes except Media3 error codes). Unit tested.
│   ├── OutputNamer       safe output file names, "name (1).mp4" de-duplication
│   ├── StorageGuard      "is there enough free space?" (needs 2 copies at peak)
│   ├── LongVideoPolicy   when to show the long-video hint (>30 min or >2 GiB)
│   ├── ProgressMath      clamp progress to 0..100, never go backwards
│   ├── TrackSummary      counts audio/video tracks from MIME types
│   ├── ErrorMapper       Media3 ExportException -> our ErrorKind
│   └── Formatters        durations and sizes
├── media/   Android-specific work (all off the main thread except Media3's own API calls)
│   ├── VideoInspector    name, size, duration, has-audio of the picked video
│   ├── TrackInspector    MediaExtractor: lists audio/video tracks of a file
│   ├── SilentExporter    Media3 Transformer with setRemoveAudio(true), progress, cancel
│   └── GallerySaver      MediaStore (Android 10+) or Movies folder + media scanner (7-9)
└── ui/
    ├── MainViewModel     the pipeline + a single StateFlow<UiState>
    ├── UiState           Idle / Loading / Selected / Processing / Success / Failure
    ├── MainActivity      draws the state; Photo Picker, share sheet, language switch
    └── LocaleHelper      English / Pashto switch
```

**Pipeline:** pick video → read info → check free space → remove audio (Media3) → verify the result has video and **no audio track** → copy into `Movies/SilentVideo` through MediaStore → delete the temporary file → show success with Share.

### How the requirements are met

| Requirement | How |
|---|---|
| Remove audio, keep the original video | `EditedMediaItem.Builder(...).setRemoveAudio(true)` with **no video effects and no target format**. When the video is already in a format MP4 accepts (H.264, H.265, ...), Media3 copies it without re-encoding ("transmuxing"): no quality loss, very fast. If the format can't go into an MP4, Media3 falls back to re-encoding just that track. |
| Result has no audio | After export the file is opened with `MediaExtractor`; if it has any audio track (or no video track) it is rejected and **not** saved. |
| No unnecessary permissions | Video is chosen with the system **Photo Picker** (falls back to the system file picker on phones without it). Saving uses **MediaStore** with `RELATIVE_PATH` + `IS_PENDING` on Android 10+: no permission. `WRITE_EXTERNAL_STORAGE` is declared with `maxSdkVersion="28"`, so it only applies to Android 7-9, where it is required. |
| Off the main thread | Media3 does the heavy work on its own threads (Transformer's API must be called from one Looper thread, here the main thread, and it only starts the job and polls progress every 250 ms). File inspection, space checks, verification and the gallery copy run on `Dispatchers.IO`. |
| Progress | `Transformer.getProgress(ProgressHolder)`. When Media3 can't report progress the bar becomes indeterminate. |
| Cancellation | Cancel stops Transformer (`transformer.cancel()`), aborts the gallery copy between 256 KB chunks, removes any half-written MediaStore entry, and deletes the temp file. |
| Unsupported / broken video | Pre-checked with `MediaExtractor`; Media3 error codes are mapped to friendly messages (`ErrorMapper`). A non-video file is rejected. |
| Long videos | Hint shown above 30 min or 2 GiB, screen kept on while working, free-space check up front. Nothing is blocked. |
| Output cleanup | The temp file is deleted in a `finally` block (success, error or cancel). Leftovers from a killed process are deleted the next time the app starts. |

### Versions used

| Component | Version | Notes |
|---|---|---|
| Media3 (`media3-transformer`, `media3-common`) | **1.11.1** | Latest stable per the Android release notes (Sep 10 2026). Public API names were checked against the 1.11.1 source tag. |
| Android Gradle Plugin | **9.5.0** | Latest stable per the Android docs. AGP 9 has Kotlin built in, so there is **no** `org.jetbrains.kotlin.android` plugin. |
| Gradle | **9.6.0** | Minimum required by AGP 9.5. |
| `activity-ktx` | 1.13.0 | Latest stable per the AndroidX release page. |
| `lifecycle-viewmodel-ktx`, `lifecycle-runtime-ktx` | 2.11.0 | Latest stable per the AndroidX release page. |
| `kotlinx-coroutines-android` | 1.10.2 | Not looked up online; a known released version. Android Studio will offer newer ones. |
| JUnit | 4.13.2 | Not looked up online; a known released version. |
| `compileSdk` / `targetSdk` / `minSdk` | 36 / 36 / 24 | Media3 1.11.1 itself is built with compileSdk 36. |

## Build instructions

You need a **computer** (Windows, macOS or Linux) for this. Android Studio cannot run on a phone.

1. Install the latest stable **Android Studio** from <https://developer.android.com/studio>. It includes the JDK (17+) and the Android SDK tools. If Studio says it is too old for AGP 9.5, use *Help → Check for Updates*.
2. Unzip `SilentVideo.zip`.
3. In Android Studio choose **File → Open** and select the `SilentVideo` folder (the one that contains `settings.gradle.kts`).
4. Wait for **Gradle sync** to finish (first time: a few minutes, it downloads Gradle 9.6.0, Media3 and the Android platform 36). If it asks to install *Android SDK Platform 36*, accept.
5. Build the debug APK:
   - **Menu:** *Build → Build Bundle(s) / APK(s) → Build APK(s)*, then click **locate** in the popup. Or
   - **Terminal** (inside the project folder): `./gradlew assembleDebug` (Windows: `gradlew.bat assembleDebug`)
6. The APK is at `app/build/outputs/apk/debug/app-debug.apk`.
7. Install on a phone: enable *Developer options → USB debugging*, connect the phone and press **Run ▶** in Android Studio, or copy `app-debug.apk` to the phone and open it (you must allow "install unknown apps" for your file manager).

### Run the unit tests

- Android Studio: right-click `app/src/test` → **Run 'Tests in ...'**, or
- Terminal: `./gradlew testDebugUnitTest`

### If the build fails

- *"requires compileSdk 37"* (or similar) on a dependency: set `compileSdk` higher in `app/build.gradle.kts` (AGP 9.5 supports it).
- *"The 'org.jetbrains.kotlin.android' plugin is no longer required"*: you added the Kotlin plugin; remove it. AGP 9 already compiles Kotlin.
- Gradle version errors: open `gradle/wrapper/gradle-wrapper.properties` and make sure the `distributionUrl` ends with `gradle-9.6.0-bin.zip` (or whatever AGP's message asks for).
- Android Studio's *Upgrade Assistant* (shown in the Gradle notification) can fix version mismatches automatically.

## Using the app

1. Tap the gold box (or **Browse files instead**) and pick a video. You can also use **Share → Silent Video** from your gallery.
2. Tap **Remove sound**. A progress bar is shown; **Cancel** stops everything.
3. When it says **Done!**, the video is in your gallery under *Movies/SilentVideo* (named `<original>_silent.mp4`). Tap **Share** to send it.
4. The **پښتو / English** button (top corner) switches the language.

## What has and has not been verified

**Verified in this workspace**
- Media3 1.11.1, AGP, Gradle, Kotlin-plugin and AndroidX versions were checked against Google's release pages; every Media3 class/method/constant used (`Transformer.Builder`, `Transformer.Listener.onCompleted/onError`, `start(EditedMediaItem, String)`, `getProgress`, `PROGRESS_STATE_AVAILABLE`, `ProgressHolder.progress`, `cancel()`, `EditedMediaItem.Builder.setRemoveAudio`, `ExportException.errorCode` and the `ERROR_CODE_*` constants) was confirmed in the 1.11.1 source.
- All XML files are well-formed, and every `R.string` / `R.id` / `@drawable` the code uses exists (English and Pashto string sets match).
- The pure-logic code in `core/` and its 39 unit tests were compiled with a Kotlin 2.0.21 compiler and run, using small stand-ins for JUnit and the two Media3 classes it touches. All 39 passed. This is **not** the Gradle/JUnit run you will do in Android Studio.

**Not verified**
- The Gradle build / APK: there is no Android SDK here and Google's Maven repository is not reachable from this workspace.
- Anything that needs a device: the actual export, the gallery save, the Photo Picker, the Android 7-9 save path, progress behaviour, the UI appearance, and the Pashto layout.
- Pashto wording: written by an AI. **Please have a native Pashto speaker review `res/values-ps/strings.xml`.**

## Known limitations

- Processing runs while the app is open. If Android kills the app in the background mid-export, the job stops (the temp file is cleaned up on next launch). Very long videos would be better served by a foreground service; this is left out to keep the app simple and the permission list short.
- Free-space check is a conservative estimate (two copies at peak).
- Videos whose format Media3 cannot read are reported as unsupported.
- The release build is unsigned and not minified. Signing/publishing is up to you and is not part of this project.

## License

Your project. Dependencies keep their own licenses (Media3, AndroidX and Kotlin coroutines are Apache 2.0; JUnit is EPL 1.0, test-only).
