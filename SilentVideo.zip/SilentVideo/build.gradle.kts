// Top-level build file. Versions of the build tools live here.
//
// AGP 9.x has Kotlin support built in, so the old "org.jetbrains.kotlin.android"
// plugin must NOT be added (it causes a build error with AGP 9).
plugins {
    id("com.android.application") version "9.5.0" apply false
}
