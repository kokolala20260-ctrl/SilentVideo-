# No custom rules needed. Only used if you enable minification in app/build.gradle.kts.
