plugins {
    id("com.android.application")
}

android {
    namespace = "app.silentvideo"
    compileSdk = 36

    defaultConfig {
        applicationId = "app.silentvideo"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            // Kept off so a beginner's first release build is simple and predictable.
            // Media3 ships its own consumer ProGuard rules if you later turn this on.
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // Media3 Transformer: the open-source (Apache 2.0) library that does the export.
    // 1.11.1 = latest stable at the time of writing (checked against Google's release notes).
    val media3 = "1.11.1"
    implementation("androidx.media3:media3-transformer:$media3")
    implementation("androidx.media3:media3-common:$media3")

    // Activity Result APIs (Photo Picker / file picker) and ComponentActivity.
    implementation("androidx.activity:activity-ktx:1.13.0")

    // ViewModel + lifecycle-aware collection of state.
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.11.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.11.0")

    // Coroutines keep the work off the main thread.
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")

    testImplementation("junit:junit:4.13.2")
}
