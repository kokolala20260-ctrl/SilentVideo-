package app.silentvideo.core

import androidx.media3.common.ParserException
import androidx.media3.transformer.ExportException

/** Converts Media3 [ExportException] error codes into our own, translated [ErrorKind]s. */
object ErrorMapper {

    fun fromExportException(e: ExportException): ErrorKind =
        fromExportErrorCode(e.errorCode, causeChain(e))

    /** Pure overload (takes plain numbers) so tests don't need to build real exceptions. */
    fun fromExportErrorCode(errorCode: Int, causes: List<Throwable> = emptyList()): ErrorKind {
        if (isNoSpace(causes)) return ErrorKind.NO_SPACE
        if (causes.any { it is ParserException }) return ErrorKind.UNSUPPORTED_FORMAT

        return when (errorCode) {
            ExportException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
            ExportException.ERROR_CODE_ENCODING_FORMAT_UNSUPPORTED,
            ExportException.ERROR_CODE_DECODER_INIT_FAILED,
            ExportException.ERROR_CODE_ENCODER_INIT_FAILED -> ErrorKind.UNSUPPORTED_FORMAT

            ExportException.ERROR_CODE_IO_FILE_NOT_FOUND,
            ExportException.ERROR_CODE_IO_NO_PERMISSION,
            ExportException.ERROR_CODE_IO_UNSPECIFIED,
            ExportException.ERROR_CODE_IO_READ_POSITION_OUT_OF_RANGE -> ErrorKind.CANNOT_OPEN

            else -> ErrorKind.GENERIC
        }
    }

    /** True if any error in the chain is the operating system's "disk full" error. */
    fun isNoSpace(causes: List<Throwable>): Boolean = causes.any {
        val msg = it.message ?: return@any false
        msg.contains("ENOSPC", ignoreCase = true) ||
            msg.contains("No space left", ignoreCase = true)
    }

    fun causeChain(throwable: Throwable, limit: Int = 8): List<Throwable> {
        val chain = ArrayList<Throwable>()
        var current: Throwable? = throwable
        while (current != null && chain.size < limit) {
            chain.add(current)
            current = current.cause?.takeIf { it !== current }
        }
        return chain
    }
}
