package app.silentvideo.ui

import android.net.Uri
import app.silentvideo.core.ErrorKind
import app.silentvideo.media.VideoInfo

/** The single source of truth for what the screen shows. */
sealed interface UiState {
    /** Nothing chosen yet. */
    data object Idle : UiState

    /** Reading information about the picked video. */
    data object Loading : UiState

    /** A video is chosen and ready. */
    data class Selected(val video: VideoInfo) : UiState

    /** Working. [percent] is null while unknown. */
    data class Processing(val video: VideoInfo, val percent: Int?, val stage: Stage) : UiState

    /** Done: the silent video is in the gallery. */
    data class Success(val savedUri: Uri, val fileName: String) : UiState

    /** [video] is kept so "Try again" can start over without picking again. */
    data class Failure(val kind: ErrorKind, val video: VideoInfo?) : UiState
}

enum class Stage { REMOVING_AUDIO, SAVING }
