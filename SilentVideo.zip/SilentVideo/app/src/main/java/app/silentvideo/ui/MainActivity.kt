package app.silentvideo.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import app.silentvideo.R
import app.silentvideo.core.ErrorKind
import app.silentvideo.core.Formatters
import app.silentvideo.core.LongVideoPolicy
import kotlinx.coroutines.launch

/** One screen. It only draws [UiState]; all the work lives in [MainViewModel]. */
class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    // Android Photo Picker (no permission needed). On phones without it, the AndroidX
    // contract automatically falls back to the system document picker (Storage Access Framework).
    private val photoPicker =
        registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
            viewModel.onVideoPicked(uri)
        }

    // Explicit "browse files" route through the Storage Access Framework.
    private val filePicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            viewModel.onVideoPicked(uri)
        }

    // Only used on Android 9 and older.
    private val storagePermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) viewModel.removeAudio() else viewModel.onPermissionDenied()
        }

    // Views
    private lateinit var root: View
    private lateinit var panels: List<View>
    private lateinit var panelIdle: View
    private lateinit var panelLoading: View
    private lateinit var panelSelected: View
    private lateinit var panelProcessing: View
    private lateinit var panelSuccess: View
    private lateinit var panelError: View

    private lateinit var selectedName: TextView
    private lateinit var selectedDetails: TextView
    private lateinit var selectedAudio: TextView
    private lateinit var selectedWarning: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var progressPercent: TextView
    private lateinit var processingTitle: TextView
    private lateinit var successMessage: TextView
    private lateinit var errorMessage: TextView
    private lateinit var languageButton: Button

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()
        applySystemBarInsets()
        wireClicks()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.state.collect(::render)
            }
        }

        if (savedInstanceState == null) handleIncomingShare(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingShare(intent)
    }

    // ---- setup ---------------------------------------------------------------------------

    private fun bindViews() {
        root = findViewById(R.id.root)
        panelIdle = findViewById(R.id.panelIdle)
        panelLoading = findViewById(R.id.panelLoading)
        panelSelected = findViewById(R.id.panelSelected)
        panelProcessing = findViewById(R.id.panelProcessing)
        panelSuccess = findViewById(R.id.panelSuccess)
        panelError = findViewById(R.id.panelError)
        panels = listOf(panelIdle, panelLoading, panelSelected, panelProcessing, panelSuccess, panelError)

        selectedName = findViewById(R.id.selectedName)
        selectedDetails = findViewById(R.id.selectedDetails)
        selectedAudio = findViewById(R.id.selectedAudio)
        selectedWarning = findViewById(R.id.selectedWarning)
        progressBar = findViewById(R.id.progressBar)
        progressPercent = findViewById(R.id.progressPercent)
        processingTitle = findViewById(R.id.processingTitle)
        successMessage = findViewById(R.id.successMessage)
        errorMessage = findViewById(R.id.errorMessage)
        languageButton = findViewById(R.id.btnLanguage)

        val showingPashto = resources.configuration.locales[0].language == LocaleHelper.PASHTO
        languageButton.text = getString(R.string.language_toggle_label)
        languageButton.contentDescription = if (showingPashto) "English" else "پښتو"
    }

    private fun wireClicks() {
        findViewById<View>(R.id.panelIdle).setOnClickListener { pickVideo() }
        findViewById<View>(R.id.btnBrowse).setOnClickListener { browseFiles() }
        findViewById<View>(R.id.btnRemove).setOnClickListener { requestRemoval() }
        findViewById<View>(R.id.btnChange).setOnClickListener { pickVideo() }
        findViewById<View>(R.id.btnCancel).setOnClickListener { viewModel.cancel() }
        findViewById<View>(R.id.btnShare).setOnClickListener { shareResult() }
        findViewById<View>(R.id.btnAnother).setOnClickListener { viewModel.reset() }
        findViewById<View>(R.id.btnRetry).setOnClickListener { retry() }
        findViewById<View>(R.id.btnErrorChoose).setOnClickListener { viewModel.reset() }
        languageButton.setOnClickListener { toggleLanguage() }
    }

    /** Keeps content out from under the status / navigation bars (edge-to-edge on Android 15+). */
    @Suppress("DEPRECATION")
    private fun applySystemBarInsets() {
        root.setOnApplyWindowInsetsListener { view, insets ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val bars = insets.getInsets(
                    WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout(),
                )
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            } else {
                view.setPadding(
                    insets.systemWindowInsetLeft,
                    insets.systemWindowInsetTop,
                    insets.systemWindowInsetRight,
                    insets.systemWindowInsetBottom,
                )
            }
            insets
        }
        root.requestApplyInsets()
    }

    // ---- actions -------------------------------------------------------------------------

    private fun pickVideo() {
        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
    }

    private fun browseFiles() {
        filePicker.launch(arrayOf("video/*"))
    }

    private fun requestRemoval() {
        val needsLegacyPermission = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
            PackageManager.PERMISSION_GRANTED
        if (needsLegacyPermission) {
            storagePermission.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            viewModel.removeAudio()
        }
    }

    private fun retry() {
        requestRemoval()
    }

    private fun shareResult() {
        val saved = viewModel.state.value as? UiState.Success ?: return
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "video/mp4"
            putExtra(Intent.EXTRA_STREAM, saved.savedUri)
            clipData = android.content.ClipData.newRawUri(saved.fileName, saved.savedUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(Intent.createChooser(send, getString(R.string.share_chooser_title)))
        } catch (_: Exception) {
            Toast.makeText(this, R.string.error_generic, Toast.LENGTH_LONG).show()
        }
    }

    private fun toggleLanguage() {
        val showingPashto = resources.configuration.locales[0].language == LocaleHelper.PASHTO
        LocaleHelper.save(this, if (showingPashto) LocaleHelper.ENGLISH else LocaleHelper.PASHTO)
        recreate() // state lives in the ViewModel, so nothing is lost
    }

    /** "Share > Silent Video" from the gallery. */
    @Suppress("DEPRECATION")
    private fun handleIncomingShare(intent: Intent?) {
        if (intent?.action != Intent.ACTION_SEND) return
        if (intent.type?.startsWith("video/") != true) return
        val uri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            intent.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri
        }
        viewModel.onVideoPicked(uri)
    }

    // ---- drawing -------------------------------------------------------------------------

    private fun show(panel: View) {
        panels.forEach { it.visibility = if (it === panel) View.VISIBLE else View.GONE }
    }

    private fun render(state: UiState) {
        // Keep the screen on while working so a long export isn't interrupted by screen-off.
        if (state is UiState.Processing) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }

        when (state) {
            UiState.Idle -> show(panelIdle)
            UiState.Loading -> show(panelLoading)

            is UiState.Selected -> {
                val v = state.video
                selectedName.text = v.displayName ?: getString(R.string.unnamed_video)

                val details = listOfNotNull(
                    v.durationMs?.let { getString(R.string.duration_label, Formatters.duration(it)) },
                    v.sizeBytes?.let { getString(R.string.size_label, Formatters.size(it)) },
                )
                selectedDetails.text = details.joinToString("  •  ")
                selectedDetails.visibility = if (details.isEmpty()) View.GONE else View.VISIBLE

                selectedAudio.setText(
                    when (v.hasAudio) {
                        true -> R.string.audio_present
                        false -> R.string.audio_absent
                        null -> R.string.audio_unknown
                    },
                )
                selectedWarning.visibility =
                    if (LongVideoPolicy.isLong(v.durationMs, v.sizeBytes)) View.VISIBLE else View.GONE
                show(panelSelected)
            }

            is UiState.Processing -> {
                val percent = state.percent
                processingTitle.setText(
                    if (state.stage == Stage.SAVING) R.string.saving_title else R.string.processing_title,
                )
                if (percent == null || state.stage == Stage.SAVING) {
                    progressBar.isIndeterminate = true
                    progressPercent.text = ""
                } else {
                    progressBar.isIndeterminate = false
                    progressBar.progress = percent
                    progressPercent.text = getString(R.string.percent_format, percent)
                }
                findViewById<View>(R.id.btnCancel).isEnabled = true
                show(panelProcessing)
            }

            is UiState.Success -> {
                successMessage.text = getString(R.string.success_message)
                show(panelSuccess)
            }

            is UiState.Failure -> {
                errorMessage.setText(messageFor(state.kind))
                // "Try again" only makes sense when we still know which video to retry.
                findViewById<View>(R.id.btnRetry).visibility =
                    if (state.video != null) View.VISIBLE else View.GONE
                show(panelError)
            }
        }
    }

    private fun messageFor(kind: ErrorKind): Int = when (kind) {
        ErrorKind.UNSUPPORTED_FORMAT -> R.string.error_unsupported
        ErrorKind.CANNOT_OPEN -> R.string.error_cannot_open
        ErrorKind.NOT_A_VIDEO -> R.string.error_not_video
        ErrorKind.NO_SPACE -> R.string.error_no_space
        ErrorKind.PERMISSION_NEEDED -> R.string.error_permission
        ErrorKind.SAVE_FAILED -> R.string.error_save_failed
        ErrorKind.OUTPUT_INVALID -> R.string.error_output_invalid
        ErrorKind.GENERIC -> R.string.error_generic
    }
}
