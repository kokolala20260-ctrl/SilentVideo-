package app.silentvideo.core

/** How many audio / video tracks a media file contains, based on the tracks' MIME types. */
data class TrackSummary(val audioTracks: Int, val videoTracks: Int) {
    val hasAudio: Boolean get() = audioTracks > 0
    val hasVideo: Boolean get() = videoTracks > 0

    companion object {
        fun fromMimeTypes(mimeTypes: List<String?>): TrackSummary {
            var audio = 0
            var video = 0
            for (mime in mimeTypes) {
                val m = mime?.lowercase() ?: continue
                if (m.startsWith("audio/")) audio++
                else if (m.startsWith("video/")) video++
            }
            return TrackSummary(audio, video)
        }
    }
}
