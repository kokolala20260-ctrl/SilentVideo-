package app.silentvideo.ui

import android.app.Application
import android.net.Uri
import android.os.Environment
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.transformer.ExportException
import app.silentvideo.core.ErrorKind
import app.silentvideo.core.ErrorMapper
import app.silentvideo.core.OutputNamer
import app.silentvideo.core.ProgressMath
import app.silentvideo.core.SilentVideoException
import app.silentvideo.core.StorageGuard
import app.silentvideo.media.GallerySaver
import app.silentvideo.media.SilentExporter
import app.silentvideo.media.TrackInspector
import app.silentvideo.media.VideoInfo
import app.silentvideo.media.VideoInspector
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

/**
 * Holds the screen state and runs the pipeline:
 * inspect -> check space -> remove audio (Media3) -> verify -> save to gallery -> clean up.
 * The ViewModel survives screen rotation, so processing is not restarted by it.
 */
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val inspector = VideoInspector(application)
    private val exporter = SilentExporter(application)
    private val saver = GallerySaver(application)
    private val exportDir = File(application.cacheDir, "exports")

    private val _state = MutableStateFlow<UiState>(UiState.Idle)
    val state: StateFlow<UiState> = _state.asStateFlow()

    private var job: Job? = null

    /** Deletes leftovers from a previous run that was killed mid-way. */
    private val startupCleanup: Job = viewModelScope.launch(Dispatchers.IO) {
        exportDir.listFiles()?.forEach { it.delete() }
    }

    fun onVideoPicked(uri: Uri?) {
        if (uri == null) return
        val current = _state.value
        if (current is UiState.Processing || current is UiState.Loading) return

        job?.cancel()
        job = viewModelScope.launch {
            _state.value = UiState.Loading
            _state.value = try {
                UiState.Selected(inspector.inspect(uri))
            } catch (e: CancellationException) {
                throw e
            } catch (e: SilentVideoException) {
                UiState.Failure(e.kind, null)
            } catch (e: Exception) {
                UiState.Failure(ErrorKind.GENERIC, null)
            }
        }
    }

    /** Starts removing the audio from the currently selected (or failed) video. */
    fun removeAudio() {
        val video = when (val s = _state.value) {
            is UiState.Selected -> s.video
            is UiState.Failure -> s.video
            else -> null
        } ?: return

        job?.cancel()
        job = viewModelScope.launch { runPipeline(video) }
    }

    /** User pressed Cancel. The pipeline cleans up after itself. */
    fun cancel() {
        if (_state.value is UiState.Processing) job?.cancel()
    }

    /** Back to the start screen. */
    fun reset() {
        job?.cancel()
        _state.value = UiState.Idle
    }

    /** Android 9 and older: the user refused the storage permission. */
    fun onPermissionDenied() {
        val video = (_state.value as? UiState.Selected)?.video
            ?: (_state.value as? UiState.Failure)?.video
        _state.value = UiState.Failure(ErrorKind.PERMISSION_NEEDED, video)
    }

    private suspend fun runPipeline(video: VideoInfo) {
        val temp = File(exportDir, OutputNamer.tempFileName(System.currentTimeMillis()))
        try {
            startupCleanup.join()
            _state.value = UiState.Processing(video, null, Stage.REMOVING_AUDIO)

            withContext(Dispatchers.IO) { ensureEnoughSpace(video) }

            exporter.export(video.uri, temp) { percent ->
                val current = _state.value
                if (current is UiState.Processing && current.stage == Stage.REMOVING_AUDIO) {
                    _state.value = current.copy(percent = ProgressMath.smooth(current.percent, percent))
                }
            }

            withContext(Dispatchers.IO) { verifyOutput(temp) }

            _state.value = UiState.Processing(video, 100, Stage.SAVING)
            val displayName = OutputNamer.outputFileName(video.displayName)
            val savedUri = saver.save(temp, displayName)

            _state.value = UiState.Success(savedUri, displayName)
        } catch (e: CancellationException) {
            // Cancelled by the user: go back to the "ready" screen. If reset() already moved
            // us elsewhere (e.g. to Idle), don't overwrite that.
            if (_state.value is UiState.Processing) _state.value = UiState.Selected(video)
            throw e
        } catch (e: SilentVideoException) {
            _state.value = UiState.Failure(e.kind, video)
        } catch (e: ExportException) {
            _state.value = UiState.Failure(ErrorMapper.fromExportException(e), video)
        } catch (e: Exception) {
            _state.value = UiState.Failure(ErrorKind.GENERIC, video)
        } finally {
            // Always remove the temporary file (success, error or cancel).
            withContext(NonCancellable + Dispatchers.IO) { temp.delete() }
        }
    }

    @Suppress("DEPRECATION")
    private fun ensureEnoughSpace(video: VideoInfo) {
        exportDir.mkdirs()
        val free = minOf(
            exportDir.usableSpace,
            Environment.getExternalStorageDirectory().usableSpace,
        )
        if (!StorageGuard.hasEnoughSpace(video.sizeBytes, free)) {
            throw SilentVideoException(ErrorKind.NO_SPACE)
        }
    }

    /** Our own safety check: the file exists, has video, and contains NO audio track. */
    private fun verifyOutput(file: File) {
        if (!file.isFile || file.length() == 0L) throw SilentVideoException(ErrorKind.OUTPUT_INVALID)
        val summary = try {
            TrackInspector.inspect(file)
        } catch (e: IOException) {
            throw SilentVideoException(ErrorKind.OUTPUT_INVALID, e)
        }
        if (!summary.hasVideo || summary.hasAudio) {
            throw SilentVideoException(ErrorKind.OUTPUT_INVALID)
        }
    }
}
