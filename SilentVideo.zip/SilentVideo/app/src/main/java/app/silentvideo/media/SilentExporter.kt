package app.silentvideo.media

import android.content.Context
import android.net.Uri
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import app.silentvideo.core.ProgressMath
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

/**
 * Removes the audio track using Media3 Transformer.
 *
 * Threading: Media3 requires Transformer to be created and called from ONE thread that has a
 * Looper (the main thread here). That is fine: the heavy work (reading, copying/encoding,
 * writing) runs on Media3's own internal threads, and the main thread only starts the job,
 * polls progress and receives the result. Call [export] from the main thread (viewModelScope).
 *
 * "Preserve the original video": we set NO video effects and NO target video format. When the
 * input video is already in a format the MP4 container accepts (e.g. H.264/H.265), Transformer
 * "transmuxes" it, i.e. copies the compressed video samples untouched: no quality loss and
 * very fast. Only if the format cannot go into an MP4 does Transformer fall back to
 * re-encoding that one track.
 */
class SilentExporter(context: Context) {
    private val appContext = context.applicationContext

    /**
     * @param onProgress called on the main thread with 0..100, or null when unknown.
     * @return the result when the export finished successfully.
     * @throws ExportException when Media3 fails.
     * @throws kotlinx.coroutines.CancellationException when the calling coroutine is cancelled
     *         (the export is cancelled too; the caller must delete [output]).
     */
    suspend fun export(input: Uri, output: File, onProgress: (Int?) -> Unit): ExportResult {
        check(Looper.myLooper() == Looper.getMainLooper()) {
            "SilentExporter.export() must be called on the main thread"
        }
        output.parentFile?.mkdirs()
        if (output.exists()) output.delete()

        val finished = CompletableDeferred<ExportResult>()
        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                finished.complete(exportResult)
            }

            override fun onError(
                composition: Composition,
                exportResult: ExportResult,
                exportException: ExportException,
            ) {
                finished.completeExceptionally(exportException)
            }
        }

        val transformer = Transformer.Builder(appContext)
            .addListener(listener)
            .build()

        val item = EditedMediaItem.Builder(MediaItem.fromUri(input))
            .setRemoveAudio(true)
            .build()

        return coroutineScope {
            val poller = launch {
                val holder = ProgressHolder()
                while (isActive) {
                    val state = transformer.getProgress(holder)
                    onProgress(
                        ProgressMath.toPercent(
                            available = state == Transformer.PROGRESS_STATE_AVAILABLE,
                            rawPercent = holder.progress,
                        ),
                    )
                    delay(POLL_INTERVAL_MS)
                }
            }
            try {
                transformer.start(item, output.absolutePath)
                finished.await()
            } finally {
                poller.cancel()
                // If we are leaving early (user cancelled), stop the export too.
                if (!finished.isCompleted) transformer.cancel()
            }
        }
    }

    private companion object {
        const val POLL_INTERVAL_MS = 250L
    }
}
