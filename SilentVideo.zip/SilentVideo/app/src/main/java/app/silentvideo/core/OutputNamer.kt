package app.silentvideo.core

/** Builds safe file names. Pure Kotlin so it is easy to unit test. */
object OutputNamer {
    private const val MAX_BASE_LENGTH = 60
    private const val SUFFIX = "_silent"
    private const val EXTENSION = ".mp4"

    /** Characters that are illegal or troublesome in file names on Android / FAT / exFAT. */
    private val illegal = Regex("""[\\/:*?"<>|\u0000-\u001F]""")

    /**
     * Takes the original display name (e.g. "Holiday: Day 1.MOV") and returns a clean base name
     * without extension (e.g. "Holiday_ Day 1"). Never returns an empty string.
     */
    fun baseName(original: String?): String {
        if (original.isNullOrBlank()) return "video"
        var name = original.trim()

        // Remove a real-looking extension (".mov", ".mp4", ".webm"), but not "my.video name".
        val dot = name.lastIndexOf('.')
        if (dot > 0) {
            val ext = name.substring(dot + 1)
            if (ext.length in 1..5 && ext.none { it.isWhitespace() }) {
                name = name.substring(0, dot)
            }
        }

        name = illegal.replace(name, "_")
        if (name.length > MAX_BASE_LENGTH) {
            name = name.substring(0, MAX_BASE_LENGTH)
            // Don't cut an emoji / surrogate pair in half.
            if (name.last().isHighSurrogate()) name = name.dropLast(1)
        }
        name = name.trim().trim('.', '_', ' ')
        return name.ifBlank { "video" }
    }

    /** "Holiday.MOV" -> "Holiday_silent.mp4". Avoids doubling the suffix. */
    fun outputFileName(original: String?): String {
        val base = baseName(original)
        val withSuffix = if (base.endsWith(SUFFIX)) base else base + SUFFIX
        return withSuffix + EXTENSION
    }

    /** Name for the temporary file in the app cache (always plain ASCII). */
    fun tempFileName(nowMillis: Long): String = "silent_$nowMillis$EXTENSION"

    /**
     * Returns [fileName] if nothing with that name exists, otherwise "name (1).mp4",
     * "name (2).mp4", ... Used on Android 9 and older where we write the file ourselves.
     */
    fun uniqueName(fileName: String, exists: (String) -> Boolean): String {
        if (!exists(fileName)) return fileName
        val dot = fileName.lastIndexOf('.')
        val stem = if (dot > 0) fileName.substring(0, dot) else fileName
        val ext = if (dot > 0) fileName.substring(dot) else ""
        var counter = 1
        while (true) {
            val candidate = "$stem ($counter)$ext"
            if (!exists(candidate)) return candidate
            counter++
        }
    }
}
