package app.silentvideo.media

import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.annotation.RequiresApi
import app.silentvideo.core.ErrorKind
import app.silentvideo.core.ErrorMapper
import app.silentvideo.core.OutputNamer
import app.silentvideo.core.SilentVideoException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.io.OutputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Copies the finished video into the phone's gallery (Movies/SilentVideo).
 *
 * Android 10+ (API 29+): uses MediaStore with RELATIVE_PATH + IS_PENDING. NO permission needed.
 * Android 7-9 (API 24-28): MediaStore cannot place files in a folder for us, so we write the
 * file into the public Movies folder (needs WRITE_EXTERNAL_STORAGE, declared with
 * maxSdkVersion=28) and ask the media scanner to add it to the gallery.
 */
class GallerySaver(context: Context) {
    private val appContext = context.applicationContext

    /** @return a content:// Uri of the saved video (valid for sharing). */
    suspend fun save(source: File, displayName: String): Uri = withContext(Dispatchers.IO) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            saveWithMediaStore(source, displayName)
        } else {
            saveLegacy(source, displayName)
        }
    }

    // ---- Android 10+ ---------------------------------------------------------------------

    @RequiresApi(Build.VERSION_CODES.Q)
    private suspend fun saveWithMediaStore(source: File, displayName: String): Uri {
        val resolver = appContext.contentResolver
        val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, MIME_MP4)
            put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/$FOLDER")
            put(MediaStore.Video.Media.IS_PENDING, 1) // hidden from other apps until complete
        }
        val uri = resolver.insert(collection, values)
            ?: throw SilentVideoException(ErrorKind.SAVE_FAILED)

        try {
            val out = resolver.openOutputStream(uri, "w")
                ?: throw SilentVideoException(ErrorKind.SAVE_FAILED)
            out.use { copy(source, it) }

            val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
            return uri
        } catch (t: Throwable) {
            // Never leave a half-written (pending) entry behind.
            try {
                resolver.delete(uri, null, null)
            } catch (_: Exception) {
            }
            throw wrap(t)
        }
    }

    // ---- Android 7-9 ---------------------------------------------------------------------

    @Suppress("DEPRECATION")
    private suspend fun saveLegacy(source: File, displayName: String): Uri {
        if (appContext.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            throw SilentVideoException(ErrorKind.PERMISSION_NEEDED)
        }
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), FOLDER)
        if (!dir.isDirectory && !dir.mkdirs() && !dir.isDirectory) {
            throw SilentVideoException(ErrorKind.SAVE_FAILED)
        }
        val target = File(dir, OutputNamer.uniqueName(displayName) { File(dir, it).exists() })

        try {
            target.outputStream().use { copy(source, it) }
        } catch (t: Throwable) {
            target.delete()
            throw wrap(t)
        }
        return scan(target)
    }

    private suspend fun scan(file: File): Uri = suspendCancellableCoroutine { cont ->
        MediaScannerConnection.scanFile(
            appContext,
            arrayOf(file.absolutePath),
            arrayOf(MIME_MP4),
        ) { _, uri ->
            if (uri != null) cont.resume(uri)
            else cont.resumeWithException(SilentVideoException(ErrorKind.SAVE_FAILED))
        }
    }

    // ---- shared --------------------------------------------------------------------------

    /** Copies in chunks and checks for cancellation between chunks. */
    private suspend fun copy(source: File, out: OutputStream) {
        val buffer = ByteArray(COPY_BUFFER_BYTES)
        source.inputStream().use { input ->
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                out.write(buffer, 0, read)
                currentCoroutineContext().ensureActive()
            }
        }
        out.flush()
    }

    private fun wrap(t: Throwable): Throwable = when {
        t is CancellationException -> t
        t is SilentVideoException -> t
        t is SecurityException -> SilentVideoException(ErrorKind.PERMISSION_NEEDED, t)
        t is IOException && ErrorMapper.isNoSpace(ErrorMapper.causeChain(t)) ->
            SilentVideoException(ErrorKind.NO_SPACE, t)
        else -> SilentVideoException(ErrorKind.SAVE_FAILED, t)
    }

    companion object {
        const val FOLDER = "SilentVideo"
        const val MIME_MP4 = "video/mp4"
        private const val COPY_BUFFER_BYTES = 256 * 1024
    }
}
