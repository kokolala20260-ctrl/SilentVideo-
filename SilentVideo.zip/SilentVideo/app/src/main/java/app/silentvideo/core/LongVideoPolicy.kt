package app.silentvideo.core

/** Decides when to show the "this is a long video" hint. Nothing is blocked; it is advice only. */
object LongVideoPolicy {
    const val LONG_DURATION_MS: Long = 30L * 60 * 1000          // 30 minutes
    const val LARGE_SIZE_BYTES: Long = 2L * 1024 * 1024 * 1024  // 2 GiB

    fun isLong(durationMs: Long?, sizeBytes: Long?): Boolean =
        (durationMs != null && durationMs > LONG_DURATION_MS) ||
            (sizeBytes != null && sizeBytes > LARGE_SIZE_BYTES)
}
