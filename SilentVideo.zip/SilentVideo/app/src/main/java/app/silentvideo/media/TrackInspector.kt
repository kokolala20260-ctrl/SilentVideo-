package app.silentvideo.media

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import app.silentvideo.core.TrackSummary
import java.io.File
import java.io.IOException

/**
 * Looks inside a media file and reports whether it has audio / video tracks.
 * Uses Android's built-in MediaExtractor, so no extra library is needed.
 * Blocking: call from a background thread.
 */
object TrackInspector {

    @Throws(IOException::class)
    fun inspect(context: Context, uri: Uri): TrackSummary =
        read { it.setDataSource(context, uri, null) }

    @Throws(IOException::class)
    fun inspect(file: File): TrackSummary =
        read { it.setDataSource(file.absolutePath) }

    private inline fun read(setup: (MediaExtractor) -> Unit): TrackSummary {
        val extractor = MediaExtractor()
        try {
            setup(extractor)
            val mimes = List(extractor.trackCount) { index ->
                extractor.getTrackFormat(index).getString(MediaFormat.KEY_MIME)
            }
            return TrackSummary.fromMimeTypes(mimes)
        } finally {
            extractor.release()
        }
    }
}
