package app.silentvideo.core

/** Every kind of failure the user can see. Each one maps to a friendly, translated message. */
enum class ErrorKind {
    /** The video's format/codec can't be handled on this phone, or the file is damaged. */
    UNSUPPORTED_FORMAT,

    /** The file could not be opened (moved, deleted, or no access any more). */
    CANNOT_OPEN,

    /** The chosen file is not a video. */
    NOT_A_VIDEO,

    /** The phone does not have enough free storage. */
    NO_SPACE,

    /** Android 9 and older only: storage permission was refused. */
    PERMISSION_NEEDED,

    /** Copying the finished video into the gallery failed. */
    SAVE_FAILED,

    /** The exported file failed our own check (empty, or still contains audio). */
    OUTPUT_INVALID,

    /** Anything else. */
    GENERIC,
}

/** Exception carrying an [ErrorKind] so the UI layer never has to inspect library errors. */
class SilentVideoException(
    val kind: ErrorKind,
    cause: Throwable? = null,
) : Exception("Silent Video error: $kind", cause)
