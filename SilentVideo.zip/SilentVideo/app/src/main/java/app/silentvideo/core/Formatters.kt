package app.silentvideo.core

import java.util.Locale

/** Small, dependency-free formatting helpers (kept out of the UI so they can be tested). */
object Formatters {
    /** 65_000 -> "1:05", 3_723_000 -> "1:02:03". */
    fun duration(millis: Long): String {
        val totalSeconds = (if (millis < 0) 0 else millis) / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%d:%02d", minutes, seconds)
        }
    }

    /** 1_572_864 -> "1.5 MB". Uses 1024-based units, like most Android screens. */
    fun size(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var value = bytes.toDouble()
        var unit = -1
        while (value >= 1024 && unit < units.lastIndex) {
            value /= 1024
            unit++
        }
        return String.format(Locale.US, "%.1f %s", value, units[unit])
    }
}
