package app.silentvideo.ui

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/**
 * Lets people switch between English and Pashto inside the app. Many phones do not list
 * Pashto in the system language settings, so an in-app switch makes the Pashto text
 * reachable for everyone. With no saved choice the phone's own language is used.
 */
object LocaleHelper {
    private const val PREFS = "silentvideo_prefs"
    private const val KEY_LANGUAGE = "language"
    const val ENGLISH = "en"
    const val PASHTO = "ps"

    fun saved(context: Context): String? =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_LANGUAGE, null)

    fun save(context: Context, language: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_LANGUAGE, language).apply()
    }

    /** Wrap the activity's base context so resources (and RTL direction) follow the choice. */
    fun wrap(base: Context): Context {
        val language = saved(base) ?: return base
        val locale = Locale.forLanguageTag(language)
        Locale.setDefault(locale)
        val config = Configuration(base.resources.configuration)
        config.setLocale(locale)
        config.setLayoutDirection(locale)
        return base.createConfigurationContext(config)
    }
}
