package app.silentvideo.core

/** Turns Media3's progress report into something safe to show. */
object ProgressMath {
    /**
     * @param available true when Transformer says progress is available right now.
     * @param rawPercent the raw percentage reported by Transformer.
     * @return 0..100, or null when progress is unknown (show an indeterminate bar).
     */
    fun toPercent(available: Boolean, rawPercent: Int): Int? =
        if (available) rawPercent.coerceIn(0, 100) else null

    /** Never let the bar jump backwards once it has shown a number. */
    fun smooth(previous: Int?, next: Int?): Int? = when {
        next == null -> previous
        previous == null -> next
        else -> maxOf(previous, next)
    }
}
