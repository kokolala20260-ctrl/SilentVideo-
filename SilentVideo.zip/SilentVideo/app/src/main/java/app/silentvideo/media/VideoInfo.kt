package app.silentvideo.media

import android.net.Uri

/** What we know about the video the user picked. Unknown values are null. */
data class VideoInfo(
    val uri: Uri,
    val displayName: String?,
    val sizeBytes: Long?,
    val durationMs: Long?,
    /** null = we could not tell. */
    val hasAudio: Boolean?,
)
