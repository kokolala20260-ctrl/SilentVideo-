package app.silentvideo.media

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import app.silentvideo.core.ErrorKind
import app.silentvideo.core.SilentVideoException
import app.silentvideo.core.TrackSummary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.FileNotFoundException
import java.io.IOException

/** Reads name, size, duration and audio presence of a picked video (off the main thread). */
class VideoInspector(private val context: Context) {

    suspend fun inspect(uri: Uri): VideoInfo = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver

        var name: String? = null
        var size: Long? = null
        try {
            resolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
                null, null, null,
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex >= 0 && !cursor.isNull(nameIndex)) name = cursor.getString(nameIndex)
                    val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
                }
            }
        } catch (_: Exception) {
            // Some providers don't support querying. The name/size are optional, so carry on.
        }

        val mime: String? = try {
            resolver.getType(uri)
        } catch (_: Exception) {
            null
        }

        val summary: TrackSummary? = try {
            TrackInspector.inspect(context, uri)
        } catch (e: SecurityException) {
            throw SilentVideoException(ErrorKind.CANNOT_OPEN, e)
        } catch (e: FileNotFoundException) {
            throw SilentVideoException(ErrorKind.CANNOT_OPEN, e)
        } catch (e: IOException) {
            // Android's extractor can't read it. If the system still says it's a video, let
            // Media3 try anyway (it supports a few things the extractor does not).
            if (mime?.startsWith("video/", ignoreCase = true) == true) null
            else throw SilentVideoException(ErrorKind.UNSUPPORTED_FORMAT, e)
        } catch (e: RuntimeException) {
            if (mime?.startsWith("video/", ignoreCase = true) == true) null
            else throw SilentVideoException(ErrorKind.UNSUPPORTED_FORMAT, e)
        }

        if (summary != null && !summary.hasVideo) {
            throw SilentVideoException(ErrorKind.NOT_A_VIDEO)
        }

        VideoInfo(
            uri = uri,
            displayName = name,
            sizeBytes = size,
            durationMs = readDuration(uri),
            hasAudio = summary?.hasAudio,
        )
    }

    private fun readDuration(uri: Uri): Long? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
        } catch (_: Exception) {
            null
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }
    }
}
