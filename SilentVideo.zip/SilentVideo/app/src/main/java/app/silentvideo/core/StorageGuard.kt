package app.silentvideo.core

/**
 * Decides whether there is enough free space before starting.
 *
 * The finished video is first written to the app's private cache and then copied into the
 * gallery, so at the peak BOTH copies exist. Removing the audio can only make the file
 * smaller, but if the video has to be re-encoded the result can be a little larger, so we
 * allow 20% extra per copy plus a small safety margin.
 */
object StorageGuard {
    const val SAFETY_MARGIN_BYTES: Long = 64L * 1024 * 1024
    const val UNKNOWN_SIZE_REQUIREMENT_BYTES: Long = 512L * 1024 * 1024

    fun requiredBytes(inputBytes: Long?): Long {
        if (inputBytes == null || inputBytes <= 0L) return UNKNOWN_SIZE_REQUIREMENT_BYTES
        if (inputBytes > (Long.MAX_VALUE - SAFETY_MARGIN_BYTES) / 3) return Long.MAX_VALUE
        val oneCopy = inputBytes + inputBytes / 5
        return oneCopy * 2 + SAFETY_MARGIN_BYTES
    }

    fun hasEnoughSpace(inputBytes: Long?, availableBytes: Long): Boolean =
        availableBytes >= requiredBytes(inputBytes)
}
