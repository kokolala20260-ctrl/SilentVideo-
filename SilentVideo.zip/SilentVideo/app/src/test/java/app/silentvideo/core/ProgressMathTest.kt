package app.silentvideo.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ProgressMathTest {
    @Test fun toPercent_clampsToRange() {
        assertEquals(50, ProgressMath.toPercent(true, 50))
        assertEquals(100, ProgressMath.toPercent(true, 150))
        assertEquals(0, ProgressMath.toPercent(true, -5))
    }

    @Test fun toPercent_unknownWhenUnavailable() {
        assertNull(ProgressMath.toPercent(false, 50))
    }

    @Test fun smooth_neverGoesBackwards() {
        assertNull(ProgressMath.smooth(null, null))
        assertEquals(5, ProgressMath.smooth(null, 5))
        assertEquals(40, ProgressMath.smooth(40, null))
        assertEquals(40, ProgressMath.smooth(40, 30))
        assertEquals(60, ProgressMath.smooth(40, 60))
    }
}
