package app.silentvideo.core

import androidx.media3.transformer.ExportException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException

class ErrorMapperTest {
    @Test fun unsupportedFormats() {
        assertEquals(
            ErrorKind.UNSUPPORTED_FORMAT,
            ErrorMapper.fromExportErrorCode(ExportException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED),
        )
        assertEquals(
            ErrorKind.UNSUPPORTED_FORMAT,
            ErrorMapper.fromExportErrorCode(ExportException.ERROR_CODE_ENCODER_INIT_FAILED),
        )
    }

    @Test fun inputProblems() {
        assertEquals(
            ErrorKind.CANNOT_OPEN,
            ErrorMapper.fromExportErrorCode(ExportException.ERROR_CODE_IO_FILE_NOT_FOUND),
        )
    }

    @Test fun otherCodes_areGeneric() {
        assertEquals(
            ErrorKind.GENERIC,
            ErrorMapper.fromExportErrorCode(ExportException.ERROR_CODE_MUXING_FAILED),
        )
        assertEquals(
            ErrorKind.GENERIC,
            ErrorMapper.fromExportErrorCode(ExportException.ERROR_CODE_UNSPECIFIED),
        )
    }

    @Test fun diskFull_winsOverTheErrorCode() {
        val causes = listOf(IOException("write failed: ENOSPC (No space left on device)"))
        assertEquals(
            ErrorKind.NO_SPACE,
            ErrorMapper.fromExportErrorCode(ExportException.ERROR_CODE_MUXING_FAILED, causes),
        )
    }

    @Test fun isNoSpace_detectsBothSpellings() {
        assertTrue(ErrorMapper.isNoSpace(listOf(IOException("No space left on device"))))
        assertTrue(ErrorMapper.isNoSpace(listOf(IOException("open failed: ENOSPC"))))
        assertFalse(ErrorMapper.isNoSpace(listOf(IOException("permission denied"), RuntimeException())))
    }

    @Test fun causeChain_followsCauses() {
        val chain = ErrorMapper.causeChain(RuntimeException("a", IOException("b", IllegalStateException("c"))))
        assertEquals(listOf("a", "b", "c"), chain.map { it.message })
    }

    @Test fun causeChain_isBounded() {
        var t: Throwable = RuntimeException("0")
        repeat(50) { t = RuntimeException("x", t) }
        assertEquals(8, ErrorMapper.causeChain(t).size)
    }
}
