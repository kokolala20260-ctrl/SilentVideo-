package app.silentvideo.core

import org.junit.Assert.assertEquals
import org.junit.Test

class OutputNamerTest {

    @Test fun baseName_removesExtension() {
        assertEquals("Holiday", OutputNamer.baseName("Holiday.MOV"))
    }

    @Test fun baseName_replacesIllegalCharacters() {
        assertEquals("Holiday_ Day 1", OutputNamer.baseName("Holiday: Day 1.mov"))
        assertEquals("a_b_c", OutputNamer.baseName("a/b\\c*.mp4"))
    }

    @Test fun baseName_keepsDotsThatAreNotExtensions() {
        assertEquals("my.video name", OutputNamer.baseName("my.video name"))
    }

    @Test fun baseName_fallsBackToVideo() {
        assertEquals("video", OutputNamer.baseName(null))
        assertEquals("video", OutputNamer.baseName("   "))
        assertEquals("video", OutputNamer.baseName("..."))
    }

    @Test fun baseName_limitsLength() {
        assertEquals(60, OutputNamer.baseName("a".repeat(100) + ".mp4").length)
    }

    @Test fun baseName_doesNotSplitEmoji() {
        // 59 letters + one emoji (2 UTF-16 chars) would be cut in the middle at 60 chars.
        val name = "a".repeat(59) + "😀" + ".mp4"
        assertEquals("a".repeat(59), OutputNamer.baseName(name))
    }

    @Test fun baseName_keepsPashtoLetters() {
        assertEquals("ویډیو", OutputNamer.baseName("ویډیو.mp4"))
    }

    @Test fun outputFileName_addsSilentSuffixAndMp4() {
        assertEquals("Holiday_silent.mp4", OutputNamer.outputFileName("Holiday.MOV"))
        assertEquals("video_silent.mp4", OutputNamer.outputFileName(null))
    }

    @Test fun outputFileName_doesNotDoubleTheSuffix() {
        assertEquals("Holiday_silent.mp4", OutputNamer.outputFileName("Holiday_silent.mp4"))
    }

    @Test fun tempFileName_isPlainAscii() {
        assertEquals("silent_123.mp4", OutputNamer.tempFileName(123L))
    }

    @Test fun uniqueName_returnsSameNameWhenFree() {
        assertEquals("a.mp4", OutputNamer.uniqueName("a.mp4") { false })
    }

    @Test fun uniqueName_addsCounter() {
        val taken = setOf("a.mp4", "a (1).mp4")
        assertEquals("a (2).mp4", OutputNamer.uniqueName("a.mp4") { it in taken })
    }

    @Test fun uniqueName_worksWithoutExtension() {
        assertEquals("a (1)", OutputNamer.uniqueName("a") { it == "a" })
    }
}
