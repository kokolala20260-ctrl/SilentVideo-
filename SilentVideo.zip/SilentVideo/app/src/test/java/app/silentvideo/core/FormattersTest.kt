package app.silentvideo.core

import org.junit.Assert.assertEquals
import org.junit.Test

class FormattersTest {
    @Test fun duration_underOneHour() {
        assertEquals("0:00", Formatters.duration(0))
        assertEquals("0:59", Formatters.duration(59_999))
        assertEquals("1:05", Formatters.duration(65_000))
    }

    @Test fun duration_overOneHour() {
        assertEquals("1:02:03", Formatters.duration(3_723_000))
    }

    @Test fun duration_negativeIsZero() {
        assertEquals("0:00", Formatters.duration(-5))
    }

    @Test fun size_units() {
        assertEquals("0 B", Formatters.size(0))
        assertEquals("1023 B", Formatters.size(1023))
        assertEquals("1.0 KB", Formatters.size(1024))
        assertEquals("1.5 MB", Formatters.size(1_572_864))
        assertEquals("1.0 GB", Formatters.size(1_073_741_824))
    }
}
