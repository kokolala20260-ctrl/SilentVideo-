package app.silentvideo.core

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LongVideoPolicyTest {
    @Test fun unknownValues_areNotLong() {
        assertFalse(LongVideoPolicy.isLong(null, null))
    }

    @Test fun duration_threshold() {
        assertFalse(LongVideoPolicy.isLong(LongVideoPolicy.LONG_DURATION_MS, null))
        assertTrue(LongVideoPolicy.isLong(LongVideoPolicy.LONG_DURATION_MS + 1, null))
    }

    @Test fun size_threshold() {
        assertFalse(LongVideoPolicy.isLong(null, LongVideoPolicy.LARGE_SIZE_BYTES))
        assertTrue(LongVideoPolicy.isLong(null, LongVideoPolicy.LARGE_SIZE_BYTES + 1))
    }

    @Test fun shortAndSmall_isNotLong() {
        assertFalse(LongVideoPolicy.isLong(60_000, 10_000_000))
    }
}
