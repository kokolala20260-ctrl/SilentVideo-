package app.silentvideo.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StorageGuardTest {
    private val mb = 1024L * 1024

    @Test fun unknownSize_usesConservativeDefault() {
        assertEquals(512 * mb, StorageGuard.requiredBytes(null))
        assertEquals(512 * mb, StorageGuard.requiredBytes(0))
        assertEquals(512 * mb, StorageGuard.requiredBytes(-5))
    }

    @Test fun knownSize_needsTwoCopiesPlusMargin() {
        // (100 MB + 20%) * 2 copies + 64 MB margin = 304 MB
        assertEquals(304 * mb, StorageGuard.requiredBytes(100 * mb))
    }

    @Test fun hasEnoughSpace_boundaries() {
        val need = StorageGuard.requiredBytes(100 * mb)
        assertTrue(StorageGuard.hasEnoughSpace(100 * mb, need))
        assertFalse(StorageGuard.hasEnoughSpace(100 * mb, need - 1))
    }

    @Test fun hugeSize_doesNotOverflow() {
        assertEquals(Long.MAX_VALUE, StorageGuard.requiredBytes(Long.MAX_VALUE))
        assertFalse(StorageGuard.hasEnoughSpace(Long.MAX_VALUE, 10_000 * mb))
    }
}
