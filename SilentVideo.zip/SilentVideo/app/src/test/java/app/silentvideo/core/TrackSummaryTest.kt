package app.silentvideo.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TrackSummaryTest {
    @Test fun countsAudioAndVideo() {
        val s = TrackSummary.fromMimeTypes(listOf("video/avc", "audio/mp4a-latm", "audio/opus"))
        assertEquals(1, s.videoTracks)
        assertEquals(2, s.audioTracks)
        assertTrue(s.hasAudio)
        assertTrue(s.hasVideo)
    }

    @Test fun silentVideo_hasNoAudio() {
        val s = TrackSummary.fromMimeTypes(listOf("video/hevc"))
        assertFalse(s.hasAudio)
        assertTrue(s.hasVideo)
    }

    @Test fun ignoresOtherTracksNullsAndCase() {
        val s = TrackSummary.fromMimeTypes(listOf(null, "text/vtt", "VIDEO/AVC"))
        assertEquals(0, s.audioTracks)
        assertEquals(1, s.videoTracks)
    }

    @Test fun emptyList() {
        val s = TrackSummary.fromMimeTypes(emptyList<String?>())
        assertFalse(s.hasAudio)
        assertFalse(s.hasVideo)
    }
}
